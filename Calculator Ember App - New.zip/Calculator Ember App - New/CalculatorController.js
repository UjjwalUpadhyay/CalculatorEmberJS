var App = Ember.Application.create();

App.IndexController = Ember.Controller.extend({
    //this.needs = ["button", "display", "numericbuttons"];
    screenElement: "",
	calculationFinished: false,
	currentSymbol: "",
    calculatorID: document.getElementById("calculator"),
	isNumValue1Done: false,
    isNumValue2Done: false,
    numValue1: 0,
    numValue2: 0,
	operateNumber: function (screenElement, inputValue)
	{
		//var displayControllerObject = new displayController();
		//var calculatorControllerObject = new calculatorController();
		var output = "";
		if ((this.calculationFinished === true) && (!isNaN(this.currentSymbol))) {
	            this.clear(event);
                this.calculationFinished = false;
				this.isNumValue1Done = false;
                displayControllerObject.display(inputValue, screenElement);
            } 
		else if ((this.calculationFinished === true) && (isNaN(this.currentSymbol))) {
                this.isNumValue1Done = true;
                output = this.numValue1 + inputValue;
                this.calculationFinished = false;
                displayControllerObject.display(output, screenElement);
            } 
        else if (this.currentSymbol === '') {
                this.inputDigits(event, screenElement);
            }
        else if (this.currentSymbol != '' && !this.isNumValue1Done) {
                this.isNumValue1Done = true;
                output = screenElement.value  + inputValue;
                this.numValue2 = inputValue;
                displayControllerObject.display(output, screenElement);
            }
        else if (this.currentSymbol != '' && this.isNumValue1Done) {
                this.numValue2 = this.numValue2 + inputValue.toString();
                output = screenElement.value + inputValue.toString();
                displayControllerObject.display(output, screenElement);
            }	

	},
	// Sum Operation
	sumOperation: function (numValue1, numValue2)
    {
     	result = numValue1 + numValue2;
     	return result;
    },
    
    subtractionOperation: function (numValue1, numValue2)
     {
     	result = numValue1 - numValue2;
     	return result;
     },
     
	 // Division operation 
     divisionOperation: function (numValue1, numValue2)
     {
     	result = numValue1 / numValue2;
     	return result;
     },

	 // Multiplication operation 
     multilpicationOperation: function (numValue1, numValue2)
     {
     	result = numValue1 * numValue2;
     	return result;
     },

     // Modulus operation 
	 modulusOperation: function (numValue1, numValue2)
     {
     	result = numValue1 % numValue2;
     	return result;
     },
     
	 // Clear functionality
     clear: function (event)
     {
		var screenElement = "";        
        if (event.target.parentNode.childNodes[0].id === "displayElement") 
			screenElement = document.getElementsByClassName('screen');
		else if (event.target.parentNode.previousSibling.previousSibling.id === "displayElement")
			screenElement = document.getElementsByClassName('screen');
        else if (typeof event === undefined)
			screenElement = screenElement;

        screenElement.value = "";
        this.numValue1 = 0;
        this.numValue2 = 0;
        this.currentSymbol = "";
        this.isNumValue1Done = false;
        this.isNumValue2Done = false;
    },
 	
	// Appending digits for numValue1 and numValue2
     inputDigits: function (event, screen)
     {
    	var num = 0;
		if (typeof event === "object") {
            num = event.target.value;
        } else {
            num = event;
        }
        if (screen.value == "" && num == "0") {
            return;
        } else if (this.calculationFinished == true) {
            screen.value = num;
            this.calculationFinished = false;
        } else {
            screen.value += num;
        }
     }	

});