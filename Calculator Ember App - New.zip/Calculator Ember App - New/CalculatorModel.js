// Calculator Model defining the properties for the calculator device
var calculatorModel = function (size, className, materials, type) {
    this.size = size;
    this.class = className;
    this.materialsUsed = material;
    this.type = type;
};

App.calculatorModel = DS.Model.extend (
    {
        size: DS.attr(string),
        class: DS.attr(string),
        materialsUsed: DS.attr(string),
        type: DS.attr(string)
    }
);