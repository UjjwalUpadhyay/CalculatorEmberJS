// Button Model containing all the properties related to the button
var buttonsModel = function (size, className, material) {
    this.size = size;
    this.class = className;
    this.materialsUsed = material;
};