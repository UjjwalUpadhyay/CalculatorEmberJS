App.NumericButtonController = Ember.Controller.extend({
	screenElement: "",
    init: function() {
	    this._super();
	    this.set("model", App.NumericButtonModel);
	},
//	currentValue : {},
	actions : {
		 click : function(event) {
		 //alert (2);
			var inputValue;
            if (typeof event === "object") {
            inputValue = event.target.value;
            this.screenElement = document.getElementsByClassName('screen')[0];
			} else {
			inputValue = event;
			}

        if (!isNaN(inputValue)) {
            var controller = App.__container__.lookup("controller:index");
            controller.send('operateNumber', this.screenElement, inputValue);
            }
	   }
}
}
);