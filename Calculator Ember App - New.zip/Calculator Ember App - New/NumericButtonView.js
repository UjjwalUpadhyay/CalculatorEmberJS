App.NumericButtonView = Ember.View.extend({
	init: function() {
	    this._super();
	    this.set("controller", App.NumericButtonController.create());
	},
	templateName : 'numeric-button',
	attributeBindings: ['data-actualValue', 'data-type'],
	click : function(e) {
		var ele = $(e.target);
		this.get('controller').send('click', event);
	}
});

