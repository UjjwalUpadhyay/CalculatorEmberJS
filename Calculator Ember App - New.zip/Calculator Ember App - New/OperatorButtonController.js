App.OperatorButtonController = Ember.Controller.extend({
	init: function() {
	    this._super();
	    this.set("model", App.OperatorButtonModel);
	},
//	currentValue : {},
	actions : {
		click : function(data) {
			//this.get('target').send('buttonClicked',data); //Not working
			var controller = App.__container__.lookup("controller:index");
			var buttonType = data.type;
			if (buttonType === "clear") {
				controller.send('clearData',data);
			} else {
				if (buttonType === "number" || (buttonType === "special" && data.value === ".")) {
					controller.send('buttonClicked',data);
				} else if (buttonType === "special") {
					controller.send('specialButtonClicked',data);
				}
			}
//			this.set("currentValue", data);
		}
	}
});
