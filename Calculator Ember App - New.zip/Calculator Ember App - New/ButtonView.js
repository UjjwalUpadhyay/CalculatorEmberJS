

App.ButtonView = Ember.View.extend({
	init: function() {
	    this._super();
	    this.set("controller", App.ButtonController.create());
	},
	templateName : 'button',
	attributeBindings: ['data-actualValue', 'data-type'],
	click : function(e) {
		var ele = $(e.target);
		this.get('controller').send('click', {
			value : ele.data("actualvalue"),
			type : ele.data("type")
		});
	}
});

